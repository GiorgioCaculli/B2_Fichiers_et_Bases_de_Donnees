/* Caculli Giorgio, Lambert Guillaume, Taminiau Tanguy */

/* Serie 7 */

/* Ex 1 */
/*------------------------------
COLMANT : OK
------------------------------*/
SELECT compagnie.indcomp, nomcomp, vol.numvol, vol.datedep FROM compagnie INNER JOIN vol ON compagnie.indcomp = vol.indcomp;

/* Ex 2 TO DO */
/*------------------------------
COLMANT : jointure sur indcomp et numvol (voir contrainte de clé étrangère)
------------------------------*/
SELECT vol.indcomp,vol.numvol, datedep, escale.nomaero, nomaerodestination FROM vol INNER JOIN escale ON escale.numvol = vol.numvol;