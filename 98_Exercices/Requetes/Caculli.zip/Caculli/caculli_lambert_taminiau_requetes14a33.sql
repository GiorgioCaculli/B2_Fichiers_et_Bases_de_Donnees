/* Requetes 1 a 13 - CACULLI GIORGIO, LAMBERT GUILLAUME, TAMINIAU TANGUY */

/*------------------
COLMANT : pour info, j'ai mis une vidéo sur Stream (accessible via Teams) pour les difficultés rencontrées avec la série 5 (séries 6 et 7 à venir)
------------------*/


/* Ex 14 */
/*------------------
COLMANT : OK
------------------*/
SELECT COUNT(*) FROM vol;

/* Ex 15 */
/*------------------
COLMANT : OK
------------------*/
SELECT COUNT(*) FROM passager WHERE nompass LIKE BINARY 'Du%';

/* Ex 16 */
/*------------------
COLMANT : distinct inutile car avec group by : une seule fois les valeurs
------------------*/
SELECT DISTINCT indcomp, COUNT(indcomp) FROM vol GROUP BY indcomp;

/* Ex 17 */
/*------------------
COLMANT : distinct inutile car avec group by : une seule fois les valeurs
------------------*/
SELECT DISTINCT indcomp, COUNT(indcomp) FROM vol WHERE indcomp='LUF' OR indcomp='SWS' GROUP BY indcomp;

/* Ex 18 TO DO */
/*------------------
COLMANT : distinct inutile car avec group by : une seule fois les valeurs, group by indcomp, numvol (identifiant du vol, voir PK)
------------------*/
SELECT DISTINCT indcomp, numvol, COUNT(*) FROM vol GROUP BY indcomp HAVING COUNT(*) > 5;

/* Ex 19 */
/*------------------
COLMANT : OK
------------------*/
SELECT SUM(nbavions) FROM compagnie;

/* Ex 20 TO DO */
/*------------------
COLMANT : SUM ne fonctionne qu'avec des numériques donc convertir la durée en secondes pour additionner puis récupérer sous forme de TIME
------------------*/
SELECT indcomp, SUM(dureevol) FROM vol GROUP BY indcomp;

/* Ex 21 TO DO */
/*------------------
COLMANT : distinct inutile car avec group by : une seule fois les valeurs, group by indcomp, numvol (identifiant du vol, voir PK) + avg et pas sum
------------------*/
SELECT DISTINCT indcomp, numvol, SUM(prixplace) FROM place GROUP BY indcomp;

/* Ex 22 */
/*------------------
COLMANT : distinct inutile car avec group by : une seule fois les valeurs
------------------*/
SELECT DISTINCT paysaero, AVG(nbterm) FROM aeroport GROUP BY paysaero HAVING AVG(nbterm) < 12;

/* Ex 23 */
/*------------------
COLMANT : pq distinct ??? max ne peut renvoyer qu'une seule valeur... distinct = éviter les doublons sur une colonne...
------------------*/
SELECT DISTINCT MAX(prixplace) FROM place;

/* Ex 24 */
/*------------------
COLMANT : distinct inutile car avec group by : une seule fois les valeurs
------------------*/
SELECT DISTINCT indcomp, MAX(dureevol) FROM vol GROUP BY indcomp;

/* Ex 25 TO DO */
/*------------------
COLMANT : la sous-requête doit permettre de déterminer quel est le plus grande nombre d'avions pour une compagnie et puis la requête principale doit afficher le nom de la compagnie pour laquelle le nombre d'avions est égal à ce max...
------------------*/
SELECT nomcomp FROM compagnie HAVING MAX(nbavions);

/* Ex 26 */

SELECT * FROM aeroport;
UPDATE aeroport SET vaccin1='Tetanos' WHERE paysaero='Belgique' OR paysaero='France';
SELECT * FROM aeroport;

/* Ex 27 TO DO */
/*------------------
COLMANT : sous-requête pour récupérer le nb de terminaux de chaque aéroport de Belgique + all comme plus grand que tous + distinct inutile car une seule fois chaque aéroport
------------------*/
SELECT DISTINCT nomaero FROM aeroport;

/* Ex 28 TO DO */
/*------------------
COLMANT : sous-requête pour récupérer le nb de terminaux de chaque aéroport de Belgique + any comme plus grand qu'au moins un + distinct inutile car une seule fois chaque aéroport
------------------*/
SELECT DISTINCT nomaero FROM aeroport;

/* Ex 29 */
/*------------------
COLMANT : OK
------------------*/
SELECT COUNT(nomaeroprinc) FROM aeroport;

/* Ex 30 */
/*------------------
COLMANT : il faut choisir entre group by et distinct (un des deux suffit)
------------------*/
SELECT DISTINCT paysaero FROM aeroport GROUP BY paysaero;

/* Ex 31 TO DO */
/*------------------
COLMANT : count(distinct numlic) si tu veux compter les pilotes différents...
------------------*/
SELECT DISTINCT COUNT(numlic) FROM vol;

/* Ex 32 TO DO */
/*------------------
COLMANT : il faut utiliser un case et un regroupement...
------------------*/
SELECT COUNT(nbheures) FROM pilote;

/* Ex 33 TO DO */
/*------------------
COLMANT : il faut utiliser une sous-requête (la sous-requête lie alors place et vol pour récupérer la durée du vol)
------------------*/
SELECT numplace, numvol, prixplace FROM place;
