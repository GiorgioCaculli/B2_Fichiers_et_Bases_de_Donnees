/* Caculli Giorgio, Lambert Guillaume, Taminiau Tanguy */

/* Serie 6 */

/* Ex 1 TO DO */
/*------------------------------
COLMANT : XOR + sous-requête pour récupérer les noms des aéroports de Belgique
------------------------------*/
SELECT * FROM vol WHERE (datedep >= "2020-03-01 00:00:00" AND dureevol >= "02:00:00") OR (datedep < "2020-03-10 00:00:00" AND nomaerodestination="Belgique");

/* Ex 2 */
/*------------------------------
COLMANT : sous-requête pour récupérer les noms des aéroports de Belgique
------------------------------*/
SELECT nomaerodestination, COUNT(*) FROM vol WHERE nomaerodestination="Zaventem" GROUP BY nomaerodestination;

/* Ex 3 */
/*------------------------------
COLMANT : sous-requête pour récupérer les noms des aéroports d'Espagne + pas de regroupement sinon un seul vol par aéroport
------------------------------*/
SELECT DISTINCT indcomp, numvol FROM escale WHERE (nomaero="Oviedo" OR nomaero="Madrid") GROUP BY nomaero;

/* Ex 4 */
/*------------------------------
COLMANT : première version, il ne faut pas % avant ver (sinon au moins 2 caractères au lieu de exactement 2 caractères) 
+ deuxième méthode avec substring
------------------------------*/
SELECT numlic, nompil FROM pilote WHERE nompil LIKE BINARY "__%ver%";

/* Ex 5 */
/*------------------------------
COLMANT : OK
------------------------------*/
SELECT numlic, nompil, nbheures FROM pilote WHERE numlic NOT IN (SELECT numlic from vol);

/* Ex 6 */
/*------------------------------
COLMANT : OK
------------------------------*/
INSERT INTO pilote(numlic, nompil, nbheures) VALUES ("PIL004", "Danny", 2500) ON DUPLICATE KEY UPDATE nompil="Haddock", nbheures=1800;
SELECT * FROM pilote;

/* Ex 7 */
/*------------------------------
COLMANT : OK
------------------------------*/
REPLACE INTO pilote(numlic, nompil, nbheures) VALUES ("PIL004", "Tintin", 3000);
SELECT * FROM pilote;

/* Ex 8 */
/*------------------------------
COLMANT : OK
------------------------------*/
INSERT INTO vol VALUES (1, "2020-04-01 10:00:00", "01:45:00", "Boeing B004", (SELECT indcomp FROM compagnie WHERE nomcomp="Air France"), "Amsterdam", "PIL004", "NAV003");
SELECT * FROM vol;

/* Ex 9 TO DO */
/*------------------------------
COLMANT : on a juste besoin de la table escale (et donc pas vol), il faut un regroupement sur base de l'id du vol (donc indcomp et numvol) et il faut rollup pour les sous-totaux et le total
------------------------------*/
/* Ex 10 */
/*------------------------------
COLMANT : OK
------------------------------*/
SELECT * FROM escale WHERE (numvol, indcomp) IN (SELECT numvol, indcomp FROM vol WHERE datedep >= "2020-03-20 00:00:00" AND datedep < "2020-03-22 00:00:00");
